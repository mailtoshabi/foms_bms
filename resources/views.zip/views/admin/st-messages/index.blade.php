@extends('admin.layouts.master')

@section('title', 'Student-Teacher Messages')

@section('content')

    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <a href="javascript:window.history.back();"
                    class="btn btn-sm btn-light border-0 shadow-sm me-2 rounded-circle" title="Go Back">
                    <i class="fas fa-chevron-left"></i>
                </a>
                <h4 class="mb-0">
                    <i class="fas fa-comments me-2"></i> Student-Teacher Messages
                </h4>
            </div>
        </div>

        <div class="card-body">

            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif

            {{-- Filters --}}
            <form method="GET" action="{{ route('admin.st-messages.index') }}" class="mb-3">
                <div class="row g-2 align-items-end">
                    <div class="col-md-5">
                        <label class="form-label fw-bold">Student or Teacher Name</label>
                        <input type="text" name="search" class="form-control"
                            placeholder="Search by student or teacher name..." value="{{ request('search') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Direction</label>
                        <select name="direction" class="form-control">
                            <option value="">All Directions</option>
                            <option value="teacher_to_student" {{ request('direction') == 'teacher_to_student' ? 'selected' : '' }}>
                                Teacher → Student
                            </option>
                            <option value="student_to_teacher" {{ request('direction') == 'student_to_teacher' ? 'selected' : '' }}>
                                Student → Teacher
                            </option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button class="btn btn-primary">Filter</button>
                        <a href="{{ route('admin.st-messages.index') }}" class="btn btn-light">Reset</a>
                    </div>
                </div>
            </form>

            @if($messages->isEmpty())
                <p class="text-muted text-center py-4">No messages found.</p>
            @else
                <div class="table-responsive">
                    <table class="table table-bordered align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Direction</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Message</th>
                                <th>Replies</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($messages as $msg)
                                @php
                                    $isTeacherSender = $msg->sender_type === 'App\Models\Teacher';
                                    $isClassReceiver = $msg->receiver_type === 'App\Models\ClassRoom';
                                    $senderRole = $isTeacherSender ? 'Teacher' : 'Student';
                                    $receiverRole = $isClassReceiver ? 'Class' : ($isTeacherSender ? 'Student' : 'Teacher');
                                @endphp
                                <tr>
                                    <td>{{ $messages->firstItem() + $loop->index }}</td>
                                    <td>
                                        @if($isTeacherSender)
                                            <span class="badge bg-primary">Teacher → {{ $isClassReceiver ? 'Class' : 'Student' }}</span>
                                        @else
                                            <span class="badge bg-success">Student → Teacher</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($msg->sender)
                                            <a
                                                href="{{ $isTeacherSender ? route('admin.reports.teachers.show', encrypt($msg->sender->id)) : route('admin.reports.students.show', encrypt($msg->sender->id)) }}">
                                                {{ $msg->sender->name }}
                                            </a>
                                            <span class="badge bg-{{ $isTeacherSender ? 'primary' : 'info' }} me-1">
                                                <small>{{ $senderRole }}</small>
                                            </span>
                                        @else
                                            -
                                        @endif
                                    </td>
                                    <td>

                                        @if($msg->receiver)
                                            <a
                                                href="{{ $isClassReceiver ? route('admin.class_rooms.show', encrypt($msg->receiver->id)) : ($isTeacherSender ? route('admin.reports.students.show', encrypt($msg->receiver->id)) : route('admin.reports.teachers.show', encrypt($msg->receiver->id))) }}">
                                                {{ $msg->receiver->name }}
                                            </a>
                                            <span
                                                class="badge bg-{{ $isClassReceiver ? 'warning text-dark' : ($isTeacherSender ? 'info' : 'primary') }} me-1">
                                                <small>{{ $receiverRole }}</small>
                                            </span>
                                        @else
                                            -
                                        @endif
                                    </td>
                                    <td>{{ Str::limit($msg->message, 60) }}</td>
                                    <td>
                                        @if($msg->replies->count() > 0)
                                            <span class="badge bg-warning text-dark">{{ $msg->replies->count() }}</span>
                                        @else
                                            <span class="text-muted">0</span>
                                        @endif
                                    </td>
                                    <td>{{ $msg->created_at->format('d M Y, h:i A') }}</td>
                                    <td>
                                        <a href="{{ route('admin.st-messages.show', encrypt($msg->id)) }}"
                                            class="btn btn-sm btn-info" title="View Thread">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="mt-3">
                    {{ $messages->links() }}
                </div>
            @endif

        </div>
    </div>

@endsection
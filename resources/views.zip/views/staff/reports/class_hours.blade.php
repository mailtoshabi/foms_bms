@extends('staff.layouts.master')
@section('title', 'Class Sessions Report')

@section('content')

    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Class Sessions</h4>
        </div>

        <div class="card-body">
            <form method="GET" action="{{ route('staff.class-hours.index') }}" class="mb-4">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Class Room</label>
                        <select name="class_room_id" id="class_room_id" class="form-control class-select2">
                            @if(request('class_room_id'))
                                <option value="{{ request('class_room_id') }}" selected>{{ $selectedClassName }}</option>
                            @endif
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-bold">Teacher</label>
                        <select name="teacher_id" id="teacher_id" class="form-control teacher-select2">
                            @if(request('teacher_id'))
                                <option value="{{ request('teacher_id') }}" selected>{{ $selectedTeacherName }}</option>
                            @endif
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label class="form-label fw-bold">Status</label>
                        <select name="status" class="form-control">
                            <option value="">All Statuses</option>
                            <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                            <option value="completed" {{ request('status') == 'completed' ? 'selected' : '' }}>Completed
                            </option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label class="form-label fw-bold">From Date</label>
                        <input type="date" name="from_date" value="{{ request('from_date') }}" class="form-control"
                            placeholder="From Date">
                    </div>

                    <div class="col-md-2">
                        <label class="form-label fw-bold">To Date</label>
                        <input type="date" name="to_date" value="{{ request('to_date') }}" class="form-control"
                            placeholder="To Date">
                    </div>

                    <div class="col-md-12 d-flex justify-content-end gap-2 mt-2">
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="mdi mdi-filter"></i> Filter
                        </button>
                        <a href="{{ route('staff.class-hours.index') }}" class="btn btn-light px-4">
                            <i class="mdi mdi-refresh"></i> Reset
                        </a>
                    </div>
                </div>
            </form>

            @if(request()->anyFilled(['class_room_id', 'teacher_id', 'status', 'from_date', 'to_date']))
                <div class="portal-info-grid mb-4">
                    <div class="portal-info-card">
                        <div class="portal-info-card-icon">
                            <i class="fas fa-video"></i>
                        </div>
                        <div class="portal-info-card-content">
                            <span class="portal-info-card-label">Total Sessions</span>
                            <span class="portal-info-card-value">{{ $totalClassHours }}</span>
                        </div>
                    </div>
                    <div class="portal-info-card">
                        <div class="portal-info-card-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="portal-info-card-content">
                            <span class="portal-info-card-label">Total Duration</span>
                            <span class="portal-info-card-value">{{ $totalDurationFormatted }}</span>
                        </div>
                    </div>
                </div>
            @endif

            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Date & Time </th>
                            <th>Join Time</th>
                            <th>Class</th>
                            <th>Teacher</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($data as $row)
                            <tr>
                                <td>
                                     <small>Created:</small><br>
                                     @if($row->created_at)
                                         {{ \Carbon\Carbon::parse($row->created_at)->format('d M Y') }}
                                         <small class="text-muted">{{ \Carbon\Carbon::parse($row->created_at)->format('h:i A') }}</small>
                                     @else
                                         <small class="text-muted">N/A</small>
                                     @endif
                                     <br>
                                     <small>Updated:</small><br>
                                     @if($row->link_updated_at)
                                         {{ \Carbon\Carbon::parse($row->link_updated_at)->format('d M Y') }}
                                         <small class="text-muted">{{ \Carbon\Carbon::parse($row->link_updated_at)->format('h:i A') }}</small>
                                     @else
                                         <small class="text-muted">N/A</small>
                                     @endif
                                 </td>
                                 <td>
                                     <small>Teacher Joined:</small><br>
                                     @if($row->join_teacher_at)
                                         {{ \Carbon\Carbon::parse($row->join_teacher_at)->format('d M Y') }}
                                         <small class="text-muted">{{ \Carbon\Carbon::parse($row->join_teacher_at)->format('h:i A') }}</small>
                                     @else
                                         <small class="text-muted">Not Joined</small>
                                     @endif
                                     <br>
                                     <small>Student Joined:</small><br>
                                     @if($row->join_student_at)
                                         {{ \Carbon\Carbon::parse($row->join_student_at)->format('d M Y') }}
                                         <small class="text-muted">{{ \Carbon\Carbon::parse($row->join_student_at)->format('h:i A') }}</small>
                                     @else
                                         <small class="text-muted">Not Joined</small>
                                     @endif
                                 </td>
                                <td>
                                    <strong><a href="{{ route('staff.class_rooms.show', encrypt($row->classRoom->id)) }}">{{ $row->classRoom->name ?? 'N/A' }}</a></strong>
                                    <br>
                                    <small>{{ $row->classRoom->course->name ?? '' }}</small>
                                </td>
                                <td><a href="{{ route('staff.teachers.show', encrypt($row->teacher->id)) }}">{{ $row->teacher->name ?? 'N/A' }}</a>
                                    <br><small>{{ $row->teacher->formatted_contact_number ?? '' }}</small>
                                </td>
                                <td>{{ $row->duration }} mins</td>
                                <td>
                                    <span class="badge {{ $row->status == 'completed' ? 'bg-success' : 'bg-warning' }}">
                                        {{ ucfirst($row->status) }}
                                    </span>
                                    @if($row->status == 'completed')
                                        <small>at</small><br>
                                        {{ \Carbon\Carbon::parse($row->completed_at)->format('d M Y') }}

                                        <small
                                            class="text-muted">{{ \Carbon\Carbon::parse($row->completed_at)->format('h:i A') }}</small>
                                    @endif
                                </td>
                                <td>
                                    @if($row->google_meet_link)
                                        <a href="{{ $row->google_meet_link }}" target="_blank"
                                            class="btn btn-sm btn-outline-primary">
                                            <i class="mdi mdi-google-meet"></i> Meet
                                        </a>
                                    @endif

                                    <div class="mt-1">
                                        @if($row->has_fee_calculated)
                                            <span class="badge badge-soft-info" title="Fees Calculated">Fee <i
                                                    class="mdi mdi-check"></i></span>
                                        @endif
                                        @if($row->has_salary_calculated)
                                            <span class="badge badge-soft-success" title="Salary Calculated">Salary <i
                                                    class="mdi mdi-check"></i></span>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No sessions found matching your criteria.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                {{ $data->links() }}
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $(document).ready(function () {
            $('.class-select2').select2({
                placeholder: "Search Class...",
                minimumInputLength: 2,
                allowClear: true,
                ajax: {
                    url: "{{ route('staff.class_rooms.search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            q: params.term
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data.results
                        };
                    },
                    cache: true
                }
            });

            $('.teacher-select2').select2({
                placeholder: "Search Teacher...",
                minimumInputLength: 2,
                allowClear: true,
                ajax: {
                    url: "{{ route('staff.teachers.search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            q: params.term
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data.results
                        };
                    },
                    cache: true
                }
            });
        });
    </script>
@endsection
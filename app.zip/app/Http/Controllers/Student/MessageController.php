<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\ClassRoom;
use App\Models\Message;
use App\Models\Student;
use App\Models\Teacher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MessageController extends Controller
{
    public function index()
    {
        $student      = Auth::guard('student')->user();
        $classRoomIds = $student->class_rooms()->pluck('class_rooms.id');

        $messages = Message::whereNull('reply_to_id')
            ->where(function ($q) use ($student, $classRoomIds) {
                // Direct messages sent/received by this student
                $q->where(function ($q2) use ($student) {
                    $q2->where('sender_type', Student::class)->where('sender_id', $student->id);
                })->orWhere(function ($q2) use ($student) {
                    $q2->where('receiver_type', Student::class)->where('receiver_id', $student->id);
                })
                // Class-broadcast messages to any of the student's classes
                ->orWhere(function ($q2) use ($classRoomIds) {
                    $q2->where('receiver_type', ClassRoom::class)
                       ->whereIn('receiver_id', $classRoomIds);
                });
            })
            ->with(['sender', 'receiver', 'replies'])
            ->latest()
            ->get();

        return view('student.messages.index', compact('messages', 'student'));
    }

    public function create()
    {
        $student = Auth::guard('student')->user();

        $teachers = Teacher::whereHas('classRooms', function ($q) use ($student) {
            $q->whereIn('class_rooms.id', $student->class_rooms()->pluck('class_rooms.id'));
        })->get();

        return view('student.messages.create', compact('teachers'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'teacher_id' => 'required|exists:teachers,id',
            'message'    => 'required|string|max:2000',
        ]);

        $student = Auth::guard('student')->user();

        Message::create([
            'sender_type'   => Student::class,
            'sender_id'     => $student->id,
            'receiver_type' => Teacher::class,
            'receiver_id'   => $request->teacher_id,
            'message'       => $request->message,
        ]);

        return redirect()->route('student.messages.index')->with('success', 'Message sent successfully!');
    }

    public function show($id)
    {
        $student  = Auth::guard('student')->user();
        $message  = Message::with(['sender', 'receiver', 'replies.sender'])->findOrFail(decrypt($id));

        $classRoomIds = $student->class_rooms()->pluck('class_rooms.id');

        $isInvolved = ($message->sender_type == Student::class && $message->sender_id == $student->id)
            || ($message->receiver_type == Student::class && $message->receiver_id == $student->id)
            || ($message->receiver_type == ClassRoom::class && $classRoomIds->contains($message->receiver_id));

        if (!$isInvolved) {
            abort(403);
        }

        // Mark as read if the student is the receiver (direct or via classroom)
        if (!$message->is_read) {
            if ($message->receiver_type == Student::class && $message->receiver_id == $student->id) {
                $message->update(['is_read' => true]);
            } elseif ($message->receiver_type == ClassRoom::class) {
                if ($classRoomIds->contains($message->receiver_id)) {
                    $message->update(['is_read' => true]);
                }
            }
        }

        // Also mark all replies received by this student as read
        Message::where('reply_to_id', $message->id)
            ->where('is_read', false)
            ->where(function ($q) use ($student, $classRoomIds) {
                $q->where(function ($q2) use ($student) {
                    $q2->where('receiver_type', Student::class)
                        ->where('receiver_id', $student->id);
                })->orWhere(function ($q2) use ($classRoomIds) {
                    $q2->where('receiver_type', ClassRoom::class)
                        ->whereIn('receiver_id', $classRoomIds);
                });
            })
            ->update(['is_read' => true]);

        $isClassMessage = $message->receiver_type === ClassRoom::class;

        // Filter replies: for class messages students only see their own replies + the parent
        $replies = $isClassMessage
            ? $message->replies->where(function ($reply) use ($student) {
                return $reply->sender_type == Teacher::class
                    || ($reply->sender_type == Student::class && $reply->sender_id == $student->id);
            })
            : $message->replies;

        return view('student.messages.show', compact('message', 'student', 'isClassMessage', 'replies'));
    }

    public function reply(Request $request, $id)
    {
        $request->validate([
            'message' => 'required|string|max:2000',
        ]);

        $student = Auth::guard('student')->user();
        $parent  = Message::findOrFail(decrypt($id));

        $classRoomIds = $student->class_rooms()->pluck('class_rooms.id');

        $isInvolved = ($parent->sender_type == Student::class && $parent->sender_id == $student->id)
            || ($parent->receiver_type == Student::class && $parent->receiver_id == $student->id)
            || ($parent->receiver_type == ClassRoom::class && $classRoomIds->contains($parent->receiver_id));

        if (!$isInvolved) {
            abort(403);
        }

        // Always reply to the teacher who sent the original message
        if ($parent->receiver_type === ClassRoom::class) {
            $receiverType = $parent->sender_type; // Teacher
            $receiverId   = $parent->sender_id;
        } elseif ($parent->sender_type == Student::class && $parent->sender_id == $student->id) {
            $receiverType = $parent->receiver_type;
            $receiverId   = $parent->receiver_id;
        } else {
            $receiverType = $parent->sender_type;
            $receiverId   = $parent->sender_id;
        }

        Message::create([
            'reply_to_id'   => $parent->id,
            'sender_type'   => Student::class,
            'sender_id'     => $student->id,
            'receiver_type' => $receiverType,
            'receiver_id'   => $receiverId,
            'message'       => $request->message,
        ]);

        return back()->with('success', 'Reply sent successfully!');
    }
}

